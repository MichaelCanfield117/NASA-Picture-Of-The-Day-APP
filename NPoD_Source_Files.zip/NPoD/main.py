# Michael Canfield
import tkinter as tk
from gui import NasaPictureOfDayForm


def main():
    """
    Main function that runs the program.
    :return: Returns None.
    """
    root = tk.Tk()
    root.title('Nasa Picture of the Day')
    application = NasaPictureOfDayForm()
    application.mainloop()


if __name__ == '__main__':
    main()
