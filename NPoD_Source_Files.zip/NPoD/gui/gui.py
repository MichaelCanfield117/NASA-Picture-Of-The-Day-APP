import datetime

import business
from logging_config import get_logger
from PIL import Image, ImageTk
import requests
import tkinter as tk
from tkinter import ttk


logger = get_logger(__name__)


class NasaPictureOfDayForm(tk.Frame):
    """
    The main form class that handles the GUI of the program.
    """
    def __init__(self, master=None):
        """
        The initializer dunder for the class.
        :param master: The master parameter.
        """
        super().__init__(master)
        self.selected_day_value = 0
        self.selected_month_value = 0
        self.selected_year_value = 0
        self.title = ""
        self.date = ""
        self.explanation = ""
        self.url = ""
        self.year_list = []
        self.month_list = []
        self.day_list1 = []
        self.day_list2 = []
        self.day_list3 = []
        self.day_list4 = []
        self.populate_days()
        self.populate_year()
        self.populate_months()
        self.grid()
        self.create_widgets()

    def create_widgets(self) -> None:
        """
        The function that creates the widgets for the GUI program.
        :return: Returns None.
        """
        self._year_label = tk.Label(self, text='Year (Select the Year')
        self._year_label.grid(row=0, column=0, padx=10, pady=10, sticky='e')
        self._month_label = tk.Label(self, text='Month (Select the Month')
        self._month_label.grid(row=0, column=1, padx=10, pady=10)
        self._day_label = tk.Label(self, text='Day (Select the Day)')
        self._day_label.grid(row=0, column=2, padx=10, pady=10)
        self._year_selected_box = ttk.Combobox(self, values=self.year_list)
        self._year_selected_box.grid(row=1, column=0, padx=10, pady=10, sticky='e')
        self._year_selected_box.bind("<<ComboboxSelected>>", self.selected_year)
        self._year_selected_box.state(["readonly"])
        self._month_selected_box = ttk.Combobox(self, values=self.month_list)
        self._month_selected_box.grid(row=1, column=1, padx=10, pady=10)
        self._month_selected_box.bind("<<ComboboxSelected>>", self.selected_month)
        self._month_selected_box.state(["readonly"])
        self._day_selected_box = ttk.Combobox(self)
        self._day_selected_box.grid(row=1, column=2, padx=10, pady=10)
        self._day_selected_box.bind("<<ComboboxSelected>>", self.selected_day)
        self._day_selected_box.state(["readonly"])
        self._explanation_label = tk.Label(self, text='Explanation')
        self._explanation_label.grid(row=2, column=0, padx=10, pady=10)
        self._find_picture_button = tk.Button(self, text='Find a picture of the day.', command=self.selected_date)
        self._find_picture_button.grid(row=2, column=1, padx=10, pady=10)
        self._picture_label = tk.Label(self, text='Picture')
        self._picture_label.grid(row=2, column=2, padx=10, pady=10)
        self._status_label = tk.Label(self, text='Ready')
        self._status_label.grid(row=3, column=1, padx=10, pady=10, sticky='n')
        self._picture_title = tk.Label(self, text='Title:')
        self._picture_title.grid(row=3, column=0, padx=10, pady=10)
        self._picture_url = tk.Label(self, text='Picture URL: ')
        self._picture_url.grid(row=3, column=2, padx=10, pady=10)
        self._explanation_text = tk.Text(self)
        self._explanation_text.grid(row=4, column=0)
        self._explanation_text.configure(state='disabled', width=50, height=20)
        self._picture_frame = tk.Label(self)
        self._picture_frame.grid(row=4, column=2, padx=10, pady=10)
        image = ImageTk.PhotoImage(Image.open("blank_square.png"))
        self._picture_frame.configure(image=image, width=300, height=300)
        self._picture_frame.image = image
        self._picture_frame.update()
        self._reset_button = tk.Button(self, text='Reset Selection', command=self.reset_handler)
        self._reset_button.grid(row=4, column=1, padx=10, pady=30, sticky='n')
        self._export_button = tk.Button(self, text='Export', width=12, command=self.export_handler)
        self._export_button.grid(row=4, column=1, padx=10, pady=10, sticky='s')

    def populate_year(self) -> None:
        """
        The function that populates the self.year_list list.
        :return: Returns None.
        """
        i = 1994
        year = int(datetime.date.today().year)
        while i < year:
            i += 1
            self.year_list.append(i)

    def populate_months(self) -> None:
        """
        The function that populates the self.month_list list.
        :return: Returns None.
        """
        i = 0
        while i < 12:
            i += 1
            self.month_list.append(i)

    def populate_days(self) -> None:
        """
        The function that populates the day_list lists.
        :return: Returns None.
        """
        i1 = 0
        i2 = 0
        i3 = 0
        i4 = 0
        while i1 < 28:
            i1 += 1
            self.day_list1.append(i1)
        while i2 < 30:
            i2 += 1
            self.day_list2.append(i2)
        while i3 < 31:
            i3 += 1
            self.day_list3.append(i3)
        while i4 < 29:
            i4 += 1
            self.day_list4.append(i4)

    def selected_year(self, value) -> None:
        """
        The function that selects the year, handles determining leap years.
        :param value:
        :return: Returns None.
        """
        self.selected_year_value = self._year_selected_box.get()
        logger.info(f"Selected year {self.selected_year_value}")
        if int(self.selected_month_value) == 2:
            if int(self.selected_year_value) % 4 == 0:
                self._day_selected_box.configure(values=self.day_list4)
            else:
                self._day_selected_box.configure(values=self.day_list1)
        elif int(self.selected_month_value) in [4, 6, 9, 11]:
            self._day_selected_box.configure(values=self.day_list2)
        elif int(self.selected_month_value) in [1, 3, 5, 7, 8, 10, 12]:
            self._day_selected_box.configure(values=self.day_list3)

    def selected_month(self, value) -> None:
        """
        The function that selects the month, and determines the day list amounts.
        :param value:
        :return: Returns None.
        """
        self.selected_month_value = self._month_selected_box.get()
        logger.info(f"Selected month {self.selected_month_value}")
        if int(self.selected_month_value) == 2:
            if int(self.selected_year_value) % 4 == 0:
                self._day_selected_box.configure(values=self.day_list4)
            else:
                self._day_selected_box.configure(values=self.day_list1)
        elif int(self.selected_month_value) in [4, 6, 9, 11]:
            self._day_selected_box.configure(values=self.day_list2)
        elif int(self.selected_month_value) in [1, 3, 5, 7, 8, 10, 11]:
            self._day_selected_box.configure(values=self.day_list3)

    def selected_day(self, value) -> None:
        """
        The function that selects the day value.
        :param value:
        :return:
        """
        self.selected_day_value = self._day_selected_box.get()
        logger.info(f"Selected day {self.selected_day_value}")

    def selected_date(self) -> None:
        """
        The function that collates the selected data, and attempts to run the api requests.
        Updates the various widgets depending on success or failure.
        :return: Returns none.
        """
        self._find_picture_button.config(state='disabled')
        self._export_button.config(state='disabled')
        self._reset_button.config(state='disabled')
        self._status_label.configure(text='Fetching Data...')
        self._status_label.update()
        year = self.selected_year_value
        month = self.selected_month_value
        day = self.selected_day_value
        date = f"{year}-{month}-{day}"
        logger.info(f"Finding Picture of the Day with date {date}")
        explanation = business.get_picture_explanation(date)
        title = business.get_picture_title(date)
        picture_url = business.get_picture_url(date)
        if explanation != "failure":
            self.title = title
            self.date = date
            self.explanation = explanation
            self.url = picture_url
            self._explanation_text.config(state='normal')
            self._explanation_text.delete(1.0, tk.END)
            self._explanation_text.insert(1.0, explanation)
            self._explanation_text.configure(state='disabled')
            self._status_label.configure(text='Ready')
            self._status_label.update()
            self._picture_title.configure(text=f'Title: {title}')
            self._picture_title.update()
            self._picture_url.configure(text=f'Picture URL: {picture_url}')
            self._picture_url.update()
            image = ImageTk.PhotoImage(Image.open(requests.get(picture_url, stream=True).raw))
            self._picture_frame.configure(image=image, width=300, height=300)
            self._picture_frame.image = image
            self._picture_frame.update()
            self._find_picture_button.config(state='normal')
            self._export_button.config(state='normal')
            self._reset_button.config(state='normal')
            logger.info(f"Picture of the day found at date {date}")
        else:
            self.title = ""
            self.date = ""
            self.explanation = ""
            self.url = ""
            self._explanation_text.configure(state='normal')
            self._explanation_text.delete(1.0, tk.END)
            self._explanation_text.insert(1.0, "Failure to get Picture Explanation")
            self._explanation_text.configure(state='disabled')
            self._status_label.config(text='Ready')
            self._status_label.update()
            self._picture_title.configure(text=f'Title:')
            self._picture_title.update()
            self._picture_url.configure(text=f'Picture URL:')
            self._picture_url.update()
            image = ImageTk.PhotoImage(Image.open("blank_square.png"))
            self._picture_frame.configure(image=image, width=300, height=300)
            self._picture_frame.image = image
            self._picture_frame.update()
            self._find_picture_button.config(state='normal')
            self._export_button.config(state='normal')
            self._reset_button.config(state='normal')
            logger.info(f"Picture of the day not found at date {date}")

    def export_handler(self) -> None:
        """
        The function that handle saving the current data to a text file.
        :return: Returns None.
        """
        if self.title != "":
            logger.info(f"Exporting Picture of the Day data for date {self.date}")
            business.save_info(self.title, self.date, self.explanation, self.url)
        else:
            pass

    def reset_handler(self) -> None:
        """
        The function that resets the various widgets and combo boxes to their starting state.
        :return: Returns None.
        """
        logger.info('Resetting GUI')
        self.title = ""
        self.date = ""
        self.explanation = ""
        self.url = ""
        self._explanation_text.configure(state='normal')
        self._explanation_text.delete(1.0, tk.END)
        self._explanation_text.insert(1.0, "")
        self._explanation_text.configure(state='disabled')
        self._status_label.config(text='Ready')
        self._status_label.update()
        self._picture_title.configure(text=f'Title:')
        self._picture_title.update()
        self._picture_url.configure(text=f'Picture URL:')
        self._picture_url.update()
        image = ImageTk.PhotoImage(Image.open("blank_square.png"))
        self._picture_frame.configure(image=image, width=300, height=300)
        self._picture_frame.image = image
        self._picture_frame.update()
        self._find_picture_button.config(state='normal')
        self._export_button.config(state='normal')
        self._reset_button.config(state='normal')
        logger.info('GUI reset')
