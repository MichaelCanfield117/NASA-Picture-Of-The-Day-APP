from logging_config import get_logger
import requests

logger = get_logger(__name__)
NASA_APOD_BASE_URL = "https://api.nasa.gov/planetary/apod"
NASA_API_KEY = "?api_key=7eF6Idqn44EV6n6cTar3csaeZoloSAofMNhRH3PF"


def picture_explanation(date: str) -> str:
    """
    Function that performs an api request to get an explanation string.
    :param date: The date string parameter.
    :return: Returns the explanation string.
    """
    logger.info(f"Finding explanation for picture of the day at date {date}")
    full_url = f"{NASA_APOD_BASE_URL}{NASA_API_KEY}&date={date}"
    response = requests.get(full_url)
    picture = response.json()
    failure = "failure"
    if response.status_code == 200:
        explanation = picture['explanation']
        logger.info(f"Explanation found for picture of the day at date {date}")
        return explanation
    else:
        logger.info(f"Failure to find data at date {date}")
        return failure


def picture_url(date: str) -> str:
    """
    Function that performs an api request to get a picture url string.
    :param date: The date string parameter.
    :return: Returns the picture url string.
    """
    logger.info(f"Finding picture url for date {date}")
    full_url = f"{NASA_APOD_BASE_URL}{NASA_API_KEY}&date={date}"
    response = requests.get(full_url)
    picture = response.json()
    failure = "failure"
    if response.status_code == 200:
        url = picture['url']
        logger.info(f"URL {url} found for date {date}")
        return url
    else:
        logger.info(f"Failure to find data at date {date}")
        return failure


def picture_title(date: str) -> str:
    """
    Function that performs an api request to get a picture title string.
    :param date: The date string parameter.
    :return: Returns the title string.
    """
    logger.info(f"Finding picture title for date {date}")
    full_url = f"{NASA_APOD_BASE_URL}{NASA_API_KEY}&date={date}"
    response = requests.get(full_url)
    picture = response.json()
    failure = "failure"
    if response.status_code == 200:
        title = picture['title']
        logger.info(f"Title: {title} found at date {date}")
        return title
    else:
        logger.info(f"Failure to find data at date {date}")
        return failure
