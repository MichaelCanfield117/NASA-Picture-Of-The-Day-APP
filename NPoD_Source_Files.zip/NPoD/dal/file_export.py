from logging_config import get_logger

logger = get_logger(__name__)
FILE_NAME = "picture_of_the_day.txt"


def save_picture_data(title: str, date: str,explanation: str, picture_url: str) -> None:
    """
    Function that saves picture data to a text file.
    :param title: The picture title parameter.
    :param date: The picture date parameter.
    :param explanation: The picture explanation paremeter.
    :param picture_url: The picture URL parameter.
    :return: Returns None.
    """
    logger.info(f"Writing file {FILE_NAME} for date {date}")
    with open(FILE_NAME, 'w') as file:
        file.write(f"Title: {title}\nDate: {date}\nExplanation: {explanation}\nURL: {picture_url}")

