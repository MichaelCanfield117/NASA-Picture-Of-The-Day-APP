import dal


def get_picture_title(date: str) -> str:
    """
    Function that calls the picture_title function from dal
    :param date: The date string parameter.
    :return: Returns a title string.
    """
    return dal.picture_title(date)


def get_picture_explanation(date: str) -> str:
    """
    Function that calls the picture_explanation function from dal
    :param date: The date string parameter
    :return: Return an explanation string.
    """
    return dal.picture_explanation(date)


def get_picture_url(date: str) -> str:
    """
    Function that calls the picture_url function from dal.
    :param date: The date string parameter
    :return: Return the url string.
    """
    return dal.picture_url(date)



