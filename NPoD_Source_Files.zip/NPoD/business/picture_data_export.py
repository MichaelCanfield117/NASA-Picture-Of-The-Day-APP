import dal
from logging_config import get_logger

logger = get_logger(__name__)


def save_info(title: str, date: str, explanation: str, url: str) -> None:
    """
    Function that calls the save_picture_data function.
    :param title: The title string parameter.
    :param date: The date string parameter.
    :param explanation: The explanation string parameter.
    :param url: The URL string parameter.
    :return: Returns None.
    """
    logger.info(f"Exporting data for date {date}")
    dal.save_picture_data(title, date, explanation, url)

