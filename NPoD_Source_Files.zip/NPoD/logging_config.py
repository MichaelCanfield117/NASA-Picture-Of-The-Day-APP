import logging as logger

logger.basicConfig(
              filename='application_log.txt',
              level=logger.INFO,
              format='[%(asctime)s - %(filename)s:%(lineno)d - %(levelname)s - %(message)s',
              datefmt='%Y-%m-%d %H:%M:%S')


def get_logger(module_name: str) -> logger:
    """
    Function that handles logging for the various packages.
    :param module_name:
    :return: Returns the getlogger
    """
    return logger.getLogger(module_name)
